@extends('layout')

@section('content')
wkwkwkw wkwkwkw wkwkwkwkw
@endsection