<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CCatagory extends Model
{
    protected $table = "ccatagory";
}
