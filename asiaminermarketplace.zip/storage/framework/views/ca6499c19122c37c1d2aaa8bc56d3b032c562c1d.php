  <script src="<?php echo e(asset('assets/frontend/js/jquery-3.3.1.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/frontend/js/jquery-migrate-3.0.1.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/frontend/js/jquery-ui.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/frontend/js/popper.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/frontend/js/bootstrap.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/frontend/js/owl.carousel.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/frontend/js/jquery.stellar.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/frontend/js/jquery.countdown.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/frontend/js/jquery.magnific-popup.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/frontend/js/bootstrap-datepicker.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/frontend/js/aos.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/frontend/js/rangeslider.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/frontend/ckeditor/ckeditor.js')); ?>"></script>

<script src="<?php echo e(asset('assets/frontend/js/main.js')); ?>"></script><?php /**PATH C:\xampp\htdocs\asiaminermarketplace\resources\views/CompanyAdmin/fragment/js.blade.php ENDPATH**/ ?>