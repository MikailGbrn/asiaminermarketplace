<?php $__env->startSection('content'); ?>
<div class="site-section bg-light">
  <div class="container mt-5">
     <div class="row">
       <div class="col-md-8">
        <div class="news">
          <div class="news-header">
            <h1><?php echo e($news->title); ?></h1>
            <p><?php echo e($news->location); ?> / <?php echo e(date( 'F j, Y',strtotime( $news->created_at ))); ?> / <?php echo e(date( 'g:i a ',strtotime( $news->created_at ))); ?></p>
            <p class="text-secondary">
            By <span><?php echo e($news->author); ?></span>
            </p>
          </div>
          <div class="image-container"><img src="<?php echo e(url('public/'.Storage::url($news->photo))); ?>"></div>
          <div class="news-body">
            <div class="abstract">
              <?php echo e($news->abstract); ?>

            </div>
            <style>.paragraf > p{
              padding-left:0px !important;
              padding-top : 10px !important; 
            }</style>
            <div class="paragraf">
              <?php 
                echo $news->description;
              ?>
            </div>
          </div>
        </div>
       </div>
       <div class="col-md-4">
         <h4 class="mb-5">Related News</h4>

         <?php $__currentLoopData = $relatedNews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <div class="related-news mb-5">
            <div class="image-container">
              <img src="<?php echo e(url('public/'.Storage::url($r->photo))); ?>">
            </div>
            <a href="<?php echo e(url("/news/$r->company_id/$r->slug")); ?>"><?php echo e($r->title); ?></a>
            <div class="abstract">
              <?php echo e($r->abstract); ?>

            </div>
         </div>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

       </div>
     </div>
  </div>




</div>
 

   

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\asiaminermarketplace\resources\views/company_news_detail.blade.php ENDPATH**/ ?>