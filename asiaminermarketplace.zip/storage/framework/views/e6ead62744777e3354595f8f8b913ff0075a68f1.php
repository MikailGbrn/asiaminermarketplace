<div class="modal fade" id="signin" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-md">
      <div class="modal-content p-4">
        <div class="modal-header">
          <h4>Sign In</h4>
        </div>
        <div class="modal-body">
            <form method="POST" action="<?php echo e(route('login')); ?>">
                <?php echo csrf_field(); ?>
                <div class="row form-group">
                  <div class="col-md-12 mb-3 mb-md-0">
                    <label class="text-black" for="fname">Email</label>
                    <input type="text" name="email" id="fname" class="form-control">
                  </div>
                  <div class="col-md-12 mb-3 mb-md-0">
                    <label class="text-black" for="lname">Password</label>
                    <input name="password" type="password" id="lname" class="form-control">
                    <input type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?> value="rememberme">
                    <label for="rememberme">Remember Me</label>
                    <?php if(Route::has('password.request')): ?>
                        <span style="float: right;"><a href="<?php echo e(route('password.request')); ?>">Forget Password?</a></span>
                    <?php endif; ?>
                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-danger"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
                </div>
                <div class="row form-group ">
                  <div class="col-md-12">
                    <input type="submit" value="Login" class="btn btn-primary btn-md text-white mb-3 mt-2">
                    <p><a href="<?php echo e(route('register')); ?>">Don't have an account?</a></p>
                  </div>
                </div>
          </form>
        </div>
      </div>
    </div>
  </div><?php /**PATH C:\xampp\htdocs\asiaminermarketplace\resources\views/CompanyAdmin/fragment/login.blade.php ENDPATH**/ ?>