<?php $__env->startSection('content'); ?>
    <div class="site-section bg-light">
      <div class="container">
        <div class="row">
          <div class="col-md-12">

            <div class="company-profile">

                <!-- header company profile -->
              <div class="profile-header">

                <img class="header" src="<?php echo e(asset('assets/frontend/images/hero_1.jpg')); ?>"> 
                <!-- profile picture company -->
                <div class="image-container">
                  <img src="<?php echo e(asset('assets/frontend/images/profile-logo.jpg')); ?>">
                </div>
              </div>



              <div class="profile-content">
              <h2><?php echo e($company->name); ?></h2>
                <p class="description"><?php echo e($company->description); ?></p>
                <p>
                <a target="_blank" href="<?php echo e($company->website); ?>"><span class="icon-paperclip mr-2 text-primary"></span><?php echo e($company->website); ?></a>
                </p>
                <p>
                  <?php $__currentLoopData = $company->address; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $address): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <span class="mr-5 text-secondary"><span class="icon-map-pin mr-2"></span><?php echo e($address->city); ?>, <?php echo e($address->province); ?></span>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <span class="text-secondary"><span class="icon-clock-o mr-2"></span><?php echo e($company->business_hour); ?></span>
                </p>
                <p>
                  <span class="mr-5 text-secondary"><span class="icon-envelope mr-2"></span><?php echo e($company->email); ?></span>
                  <span class="text-secondary"><span class="icon-phone mr-2"></span><?php echo e($company->phone); ?></span>
                </p>
              </div>

              <div class="profile-footer" style="margin-top: 12px;">
                <ul class="companynav mr-auto">
                  <li><a href="<?php echo e(url('/')); ?>/company/<?php echo e($company->slug); ?>"><span>TIMELINE</span></a></li>
                  <li><a href="<?php echo e(url('/')); ?>/company/<?php echo e($company->slug); ?>/media"><span>MEDIA/RESOURCE</span></a></li>
                  <li><a href="<?php echo e(url('/')); ?>/company/<?php echo e($company->slug); ?>/product"><span>PRODUCTS</span></a></li>
                  <li><a href="<?php echo e(url('/')); ?>/company/<?php echo e($company->slug); ?>/news"><span>NEWS</span></a></li>
                  <li><a href="<?php echo e(url('/')); ?>/company/<?php echo e($company->slug); ?>/project"><span>PROJECT</span></a></li>
                  <li class="active"><a href="<?php echo e(url('/')); ?>/company/<?php echo e($company->slug); ?>/about"><span>ABOUT</span></a></li>
                </ul>
              </div>

            </div>

          </div>
        </div>
      </div>
      <div class="container company-content">

        <!-- start of content header -->
        <div class="row mb-3">
          <div class="col-md-12">
            <h4 class="contentsection">About <?php echo e($company->name); ?></h4>
          </div>
        </div>
        <!-- end of content header -->
  
        <!-- start of content -->
        <div class="row">
  
          <div class="card">
            <div class="card-body">
              <div class="row">
                <div class="col-md-6">
                  <?php
                  echo $company->about;
                  ?>
                </div>
              </div>
            </div>
          </div>
  
        </div>
        <!-- end of content -->
  
      </div>
      <!-- media resorce content ended here -->





    </div>

 

   

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\asiaminermarketplace\resources\views/company_about.blade.php ENDPATH**/ ?>