<?php $__env->startSection('content'); ?>
<div class="site-section">
  <div class="container mt-5">
    <div class="row">
      <div class="col-md-6">
        <h2>Project (<?php echo e($project->total()); ?>)</h2>
      </div>
      <div class="col-md-6 text-right">
        <a href="<?php echo e(url('/')); ?>/company-profile/project/add"><h5>+ Add Item</h5></a>
      </div>
    </div>

    <div class="form-search-directory mt-5 ">
      <form method="get">
        <div class="row align-items-center">
          <div class="col-lg-12 col-xl-10 no-sm-border border-right">
            <input type="text" name="kw" class="form-control" placeholder="Search news">
          </div>
          <div class="col-lg-12 col-xl-2 ml-auto text-right">
            <input type="submit" class="btn text-white btn-primary" value="Search">
          </div>
          
        </div>
      </form>
    </div>

    <div class="row">
      <div class="col-md-12">
        <table class="table mt-5">
          <thead class="thead-dark">
            <tr>
              <th scope="col">#</th>
              <th scope="col">Project Title</th>
              <th scope="col">Author</th>
              <th scope="col">Date</th>
              <th scope="col">Action</th>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $project; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <th scope="row"><?php echo e($loop->iteration); ?></th>
              <td><?php echo e($n->title); ?></td>
              <td><?php echo e($n->author); ?></td>
              <td><?php echo e(date( 'F j, Y, g:i a', strtotime( $n->created_at ) )); ?></td>
              <td>
                <a href="<?php echo e(url('/')); ?>/company-profile/project/<?php echo e($n->id); ?>"><span class="icon-edit mr-5"></span></a>
                
                <a href="#" id="btnDelete" idCompany="<?php echo e($n->company_id); ?>" idProject="<?php echo e($n->id); ?>"><span class="icon-trash text-danger mr-5"></span></a>
              </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      </div>
      <div class="col-md-12">
        <?php echo e($project->links()); ?>

      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('jsplus'); ?>

<script>
  $('a#btnDelete').on('click',function()
{   
    var thisElement = $(this);

    $.ajax({
        type: 'delete',
        url: "<?php echo e(url('/')); ?>" + '/company-profile/project',
        data :{
                '_token': '<?php echo csrf_token(); ?>',
                'id' : thisElement.attr('idProject'),
                'company_id' : thisElement.attr('idCompany'),
              },
        async: false,
        success:function(response)
        {
          location.reload();
          //console.log(response);
        },
        error: function(response){
          console.log(response)
        }

    });
});
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('CompanyAdmin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\asiaminermarketplace\resources\views/CompanyAdmin/project.blade.php ENDPATH**/ ?>