    <?php $__env->startSection('content'); ?>
    <div class="site-section bg-light">
      <div class="container">
        <div class="row">
          <div class="col-md-12">

            <div class="company-profile">

                <!-- header company profile -->
              <div class="profile-header">

                <img class="header" src="<?php echo e(url('public/'.Storage::url($company->header))); ?>"> 
                <!-- profile picture company -->
                <div style="margin-top:15px" class="image-container">
                  <img style="object-position:0px 0px" src="<?php echo e(url('public/'.Storage::url($company->logo))); ?>">
                </div>
              </div>



              <div class="profile-content mt-3">
              <h2><?php echo e($company->name); ?></h2>
                <p class="description"><?php echo e($company->description); ?></p>
                <p>
                <a target="_blank" href="<?php echo e($company->website); ?>"><span class="icon-paperclip mr-2 text-primary"></span><?php echo e($company->website); ?></a>
                </p>
                <p>
                  <?php $__currentLoopData = $company->address; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $address): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <span class="mr-5 text-secondary"><span class="icon-map-pin mr-2"></span><?php echo e($address->city); ?>, <?php echo e($address->province); ?></span>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <span class="text-secondary"><span class="icon-clock-o mr-2"></span><?php echo e($company->business_hour); ?></span>
                </p>
                <p>
                  <span class="mr-5 text-secondary"><span class="icon-envelope mr-2"></span><?php echo e($company->email); ?></span>
                  <span class="text-secondary"><span class="icon-phone mr-2"></span><?php echo e($company->phone); ?></span>
                </p>
              </div>

              
              <div class="profile-footer" style="margin-top: 12px;">
                <ul class="companynav mr-auto">
                  <li class="active"><a href="<?php echo e(url('/')); ?>/company/<?php echo e($company->slug); ?>"><span>TIMELINE</span></a></li>
                  <li><a href="<?php echo e(url('/')); ?>/company/<?php echo e($company->slug); ?>/media"><span>MEDIA/RESOURCE</span></a></li>
                  <li><a href="<?php echo e(url('/')); ?>/company/<?php echo e($company->slug); ?>/product"><span>PRODUCTS</span></a></li>
                  <li><a href="<?php echo e(url('/')); ?>/company/<?php echo e($company->slug); ?>/news"><span>NEWS</span></a></li>
                  <li><a href="<?php echo e(url('/')); ?>/company/<?php echo e($company->slug); ?>/project"><span>PROJECT</span></a></li>
                  <li><a href="<?php echo e(url('/')); ?>/company/<?php echo e($company->slug); ?>/about"><span>ABOUT</span></a></li>
                </ul>
              </div>

          </div>
        </div>
      </div>

      <div class="container mt-5">
        <div class="row">
          <div class="col-md-5">
            <div class="card mb-4">
              <div class="card-header">
                <span>Media/Resources</span>
                <a href="<?php echo e(url('/')); ?>/company/<?php echo e($company->slug); ?>/media"><span>See All</span></a>
              </div>
              <div class="card-body grid-container">
                <?php $__currentLoopData = $media; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <span class="img-container grid-item">
                  <a href="<?php echo e(url('/resource/').'/'.$company->id.'/'.$m->slug); ?>">
                    <img src="<?php echo e(url('public/'.Storage::url($m->photo))); ?>">
                  </a>
                </span>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>
            </div>

            <div class="card mb-4">
              <div class="card-header">
                <span>Products</span>
                <a href="<?php echo e(url('/')); ?>/company/<?php echo e($company->slug); ?>/product"><span>See All</span></a>
              </div>
              <div class="card-body grid-container">
                <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <span class="img-container grid-item">
                  <a href="<?php echo e(url('/product/').'/'.$company->id.'/'.$p->slug); ?>">
                    <img src="<?php echo e(url('public/'.Storage::url($p->photo))); ?>">
                  </a>
                </span>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>
            </div>
          </div>
          <div class="col-md-7">
            <?php $__currentLoopData = $timeline; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($t->type == 'media'): ?>
            <div class="card2 mb-2">
              <div class="card-header">
                <h6><?php echo e($company->name); ?></h6>
                <p>Media/Resource</p>
              </div>
              <div class="card-body">
                <div class="image-container">
                  <img src="<?php echo e(url('public/'.Storage::url($t->photo))); ?>">
                </div>
                <h4><a href="<?php echo e(url('/resource/').'/'.$company->id.'/'.$t->slug); ?>"><?php echo e($t->name); ?></a></h4>
                <p>
                  <span class="icon-eye"></span>
                  <span class="mr-3">Views: <?php echo e($t->view); ?></span>
                  <span class="icon-download"></span>
                  <span>Download: <?php echo e($t->download); ?></span>
                </p>
                <p></p>
                <p><a href="<?php echo e(url('/resource/').'/'.$company->id.'/'.$t->slug); ?>">Click here to open</a></p>
              </div>
            </div>
            <?php elseif($t->type == 'product'): ?>

            <div class="card2 mb-2">
              <div class="card-header">
                <h6><?php echo e($company->name); ?></h6>
                <p>Product</p>
              </div>
              <div class="card-body">
                <div class="image-container">
                  <img src="<?php echo e(url('public/'.Storage::url($t->photo))); ?>">
                </div>
                <h4><a href="<?php echo e(url('/product/').'/'.$company->id.'/'.$t->slug); ?>"><?php echo e($t->name); ?></a></h4>
                <p>
                  <span class="icon-eye"></span>
                  <span class="mr-3">Views: <?php echo e($t->view); ?></span>
                </p>
                <p><?php echo e($t->description); ?></p>
                <p><a href="<?php echo e(url('/product/').'/'.$company->id.'/'.$t->slug); ?>">Click here to open</a></p>
              </div>
            </div>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            

          </div>
        </div>

      </div>

    </div>
    <?php $__env->stopSection(); ?>

    
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\asiaminermarketplace\resources\views/detail-directory.blade.php ENDPATH**/ ?>