    <?php $__env->startSection('content'); ?>

    <div class="site-section">
      <div class="container mt-5">
        <div class="row">
          <div class="col-md-6">
            <a href="<?php echo e(url('/')); ?>/company-profile/news"><span class="icon-arrow-left mr-3"></span>Go Back to Dashboard</a>
          </div>
        </div>
        <div class="row">
          <div class="col-md-12">
            <h2>Add New News</h2>
            <?php if($errors->any()): ?>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <strong><?php echo e($error); ?></strong>
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                          <span aria-hidden="true">&times;</span>
                        </button>
                      </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            <div class="card mt-4">
              
              <div class="card-body"> 
                <form action="<?php echo e(url('/company-profile/news')); ?>" method="post" enctype="multipart/form-data">
                  <?php echo csrf_field(); ?>
                  <div class="form-row">
                    <div class="form-group col-md-12">
                      <label for="newstitle">News Title</label>
                      <input type="text" name="title" id="newstitle" class="form-control" placeholder="Add news title">
                    </div>
                  </div>
                  <div class="form-row">
                    <div class="form-group col-md-6">
                      <label for="author">Author</label>
                      <input type="text" name="author" id="author" class="form-control" placeholder="Add author">
                    </div>
                    <div class="form-group col-md-6">
                      <label for="newslocation">News Location</label>
                      <input type="text" name="location" id="newslocation" class="form-control" placeholder="Jakarta, Indonesia">
                    </div>
                  </div>
                  <div class="form-row">
                    <div class="form-group col-md-6 mb-3">
                      <label for="photo"><span class="icon-image mr-3 ml-1"></span>Headline Image Upload </label>
                      <input type="file" name="photo" id="photo" class="form-control" accept="image/*">
                    </div>
                    <div class="form-group col-md-6">
                      <label for="newslocation">Topic</label>
                      <input type="text" name="topic" id="newslocation" class="form-control" placeholder="Mining, coal">
                    </div>
                  </div>
                  <div class="form-row">
                    <div class="form-group col-md-12">
                      <label for="abstract">News' Abstract</label>
                      <textarea class="form-control" name="abstract" id="abstract" rows="3"></textarea>
                    </div>
                  </div>
                  <div class="form-row">
                    <div class="form-group col-md-12">
                      <label for="newsbody">News Body</label>
                      <textarea name="description" id="newsbody" rows="4" class=""></textarea>
                    </div>
                  </div>
                  <div class="form-row">
                    <div class="form-group col-md-6">
                    </div>
                    <div class="form-group col-md-6" >
                      <button type="submit" class="btn btn-primary ml-5" style="float: right;">Save Changes</button>
                      <a href="<?php echo e(url('/')); ?>/company-profile/news" type="button" class="btn btn-secondary" style="float: right;">Cancel</a>
                    </div>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('CompanyAdmin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\asiaminermarketplace\resources\views/CompanyAdmin/add-news.blade.php ENDPATH**/ ?>