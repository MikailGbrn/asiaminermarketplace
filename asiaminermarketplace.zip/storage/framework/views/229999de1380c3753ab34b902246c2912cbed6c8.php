  <script src="<?php echo e(asset('assets/frontend/js/jquery-3.3.1.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/frontend/js/jquery-migrate-3.0.1.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/frontend/js/jquery-ui.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/frontend/js/popper.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/frontend/js/bootstrap.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/frontend/js/owl.carousel.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/frontend/js/jquery.stellar.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/frontend/js/jquery.countdown.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/frontend/js/jquery.magnific-popup.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/frontend/js/bootstrap-datepicker.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/frontend/js/aos.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/frontend/js/rangeslider.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/frontend/js/typed.js')); ?>"></script>
  <script>
  var typed = new Typed('.typed-words', {
  strings: ["Products"," Mining Needs"," Equipment", " Companies", " News"],
  typeSpeed: 80,
  backSpeed: 80,
  backDelay: 4000,
  startDelay: 1000,
  loop: true,
  showCursor: true
  });
  </script>

<script src="<?php echo e(asset('assets/frontend/js/main.js')); ?>"></script><?php /**PATH C:\xampp\htdocs\asiaminermarketplace\resources\views/layouts/js.blade.php ENDPATH**/ ?>