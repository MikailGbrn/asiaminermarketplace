    <?php $__env->startSection('content'); ?>

    <div class="site-section bg-light">
      <div class="container">
        <div class="row">
          <div class="col-md-12">

            <div class="company-profile">

                <!-- header company profile -->
              <div class="profile-header">

                <img class="header" src="<?php echo e(url('public/'.Storage::url($company->header))); ?>"> 
                <!-- profile picture company -->
                <div class="image-container" style="margin-top:15px">
                  <img style="object-position:0px 0px" src="<?php echo e(url('public/'.Storage::url($company->logo))); ?>">
                </div>
              </div>


              <span><a class="editbtn" style="position:absolute; right:15px" href="<?php echo e(url('/company-profile/edit')); ?>">Edit Profile</a></span>
              <div class="profile-content mt-3">
              <h2><?php echo e($company->name); ?></h2>
                <p class="description"><?php echo e($company->description); ?></p>
                <p>
                <a target="_blank" href="<?php echo e($company->website); ?>"><span class="icon-paperclip mr-2 text-primary"></span><?php echo e($company->website); ?></a>
                </p>
                <p>
                  <?php $__currentLoopData = $company->address; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $address): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <span class="mr-5 text-secondary"><span class="icon-map-pin mr-2"></span><?php echo e($address->city); ?>, <?php echo e($address->province); ?></span>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <span class="text-secondary"><span class="icon-clock-o mr-2"></span><?php echo e($company->business_hour); ?></span>
                </p>
                <p>
                  <span class="mr-5 text-secondary"><span class="icon-envelope mr-2"></span><?php echo e($company->email); ?></span>
                  <span class="text-secondary"><span class="icon-phone mr-2"></span><?php echo e($company->phone); ?></span>
                </p>
              </div>

            </div>

          </div>
          <div class="col-md-12">
            <div class="card mt-4">
              <div class="card-header">
                <h4>Company's About Page</h4>
              </div>
              <div class="card-body">
                <form action="<?php echo e(url('/company-profile/about')); ?>" method="POST">
                  <?php echo csrf_field(); ?>
                  <textarea name="about" id="about" rows="4" class=""><?php echo e($company->about); ?></textarea>
                  <center>
                    <button type="submit" class="btn btn-primary" style="margin : 10px auto">Save Changes</button>
                  </center>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>

    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('jsplus'); ?>
  <?php if($errors->any()): ?>
  <script type="text/javascript">
    $(window).on('load',function(){
        $('#additem').modal('show');
    });
  </script>
  <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('CompanyAdmin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\asiaminermarketplace\resources\views/CompanyAdmin/dashboard.blade.php ENDPATH**/ ?>