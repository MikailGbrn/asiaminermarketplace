<?php $__env->startSection('content'); ?>
wkwkwkw wkwkwkw wkwkwkwkw
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\asiaminermarketplace\resources\views/test.blade.php ENDPATH**/ ?>