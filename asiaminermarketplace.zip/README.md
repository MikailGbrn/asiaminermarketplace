<!-- <a href="http://fvcproductions.com"><img src="https://avatars1.githubusercontent.com/u/4284691?v=3&s=200" title="FVCproductions" alt="FVCproductions"></a> -->

# Mining Marketplace Project

> Gibran Fernanda as Frontend Developer

> Mohammad Arkan Mufadho as Backend Developer
